﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserObjectLayer
{
   public class Informations
    {
        public int randomVal { get; set; }
        public bool Thumb { get; set; }
        public bool Index { get; set; }
        public bool Middle { get; set; }
        public bool Ring { get; set; }
        public bool Pinky { get; set; }
        public double Thumb_Coordinate001 { get; set; }
        public double Index_Coordinate002 { get; set; }
        public double Middle_Coordinate003 { get; set; }
        public double Ring_Coordinate004 { get; set; }
        public double Pinky_Coordinate005 { get; set; }

        public int userID { get; set; }
        public int letterID { get; set; }
        public string resultString { get; set; }
        public int attempt { get; set; }

    }
}
