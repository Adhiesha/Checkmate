﻿namespace CheckMateApp
{
    partial class FogotPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PbforgotPass = new System.Windows.Forms.PictureBox();
            this.lblpuType = new System.Windows.Forms.Label();
            this.cmbpuType = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.lblprOption = new System.Windows.Forms.Label();
            this.cmbprOption = new System.Windows.Forms.ComboBox();
            this.lblpoDetails = new System.Windows.Forms.Label();
            this.txtpoDetail = new System.Windows.Forms.TextBox();
            this.pbpSearch = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblsowpass = new System.Windows.Forms.Label();
            this.lbltextPass = new System.Windows.Forms.Label();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.PbforgotPass)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbpSearch)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // PbforgotPass
            // 
            this.PbforgotPass.BackColor = System.Drawing.Color.Transparent;
            this.PbforgotPass.Image = global::CheckMateApp.Properties.Resources.forgotPassword;
            this.PbforgotPass.Location = new System.Drawing.Point(256, 41);
            this.PbforgotPass.Name = "PbforgotPass";
            this.PbforgotPass.Size = new System.Drawing.Size(226, 98);
            this.PbforgotPass.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PbforgotPass.TabIndex = 0;
            this.PbforgotPass.TabStop = false;
            // 
            // lblpuType
            // 
            this.lblpuType.AutoSize = true;
            this.lblpuType.BackColor = System.Drawing.Color.Transparent;
            this.lblpuType.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpuType.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblpuType.Location = new System.Drawing.Point(58, 199);
            this.lblpuType.Name = "lblpuType";
            this.lblpuType.Size = new System.Drawing.Size(78, 19);
            this.lblpuType.TabIndex = 1;
            this.lblpuType.Text = "User Type";
            // 
            // cmbpuType
            // 
            this.cmbpuType.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.cmbpuType.FormattingEnabled = true;
            this.cmbpuType.Location = new System.Drawing.Point(196, 189);
            this.cmbpuType.Name = "cmbpuType";
            this.cmbpuType.Size = new System.Drawing.Size(179, 28);
            this.cmbpuType.TabIndex = 2;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.RoyalBlue;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(723, 27);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "mspForm";
            // 
            // lblprOption
            // 
            this.lblprOption.AutoSize = true;
            this.lblprOption.BackColor = System.Drawing.Color.Transparent;
            this.lblprOption.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprOption.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblprOption.Location = new System.Drawing.Point(56, 251);
            this.lblprOption.Name = "lblprOption";
            this.lblprOption.Size = new System.Drawing.Size(115, 19);
            this.lblprOption.TabIndex = 4;
            this.lblprOption.Text = "Recover Option";
            // 
            // cmbprOption
            // 
            this.cmbprOption.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.cmbprOption.FormattingEnabled = true;
            this.cmbprOption.Location = new System.Drawing.Point(196, 242);
            this.cmbprOption.Name = "cmbprOption";
            this.cmbprOption.Size = new System.Drawing.Size(179, 28);
            this.cmbprOption.TabIndex = 5;
            // 
            // lblpoDetails
            // 
            this.lblpoDetails.AutoSize = true;
            this.lblpoDetails.BackColor = System.Drawing.Color.Transparent;
            this.lblpoDetails.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpoDetails.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblpoDetails.Location = new System.Drawing.Point(56, 299);
            this.lblpoDetails.Name = "lblpoDetails";
            this.lblpoDetails.Size = new System.Drawing.Size(99, 19);
            this.lblpoDetails.TabIndex = 6;
            this.lblpoDetails.Text = "Option Detail";
            // 
            // txtpoDetail
            // 
            this.txtpoDetail.Location = new System.Drawing.Point(196, 292);
            this.txtpoDetail.Multiline = true;
            this.txtpoDetail.Name = "txtpoDetail";
            this.txtpoDetail.Size = new System.Drawing.Size(179, 26);
            this.txtpoDetail.TabIndex = 7;
            // 
            // pbpSearch
            // 
            this.pbpSearch.BackColor = System.Drawing.Color.Transparent;
            this.pbpSearch.Image = global::CheckMateApp.Properties.Resources.search1;
            this.pbpSearch.Location = new System.Drawing.Point(170, 369);
            this.pbpSearch.Name = "pbpSearch";
            this.pbpSearch.Size = new System.Drawing.Size(239, 39);
            this.pbpSearch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbpSearch.TabIndex = 8;
            this.pbpSearch.TabStop = false;
            this.pbpSearch.MouseLeave += new System.EventHandler(this.pictureBox1_MouseLeave);
            this.pbpSearch.MouseHover += new System.EventHandler(this.pictureBox1_MouseHover);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.lblsowpass);
            this.panel1.Controls.Add(this.lbltextPass);
            this.panel1.Location = new System.Drawing.Point(416, 182);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(246, 146);
            this.panel1.TabIndex = 9;
            // 
            // lblsowpass
            // 
            this.lblsowpass.AutoSize = true;
            this.lblsowpass.BackColor = System.Drawing.Color.Transparent;
            this.lblsowpass.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsowpass.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblsowpass.Location = new System.Drawing.Point(96, 69);
            this.lblsowpass.Name = "lblsowpass";
            this.lblsowpass.Size = new System.Drawing.Size(40, 19);
            this.lblsowpass.TabIndex = 11;
            this.lblsowpass.Text = "Pass";
            // 
            // lbltextPass
            // 
            this.lbltextPass.AutoSize = true;
            this.lbltextPass.BackColor = System.Drawing.Color.Transparent;
            this.lbltextPass.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltextPass.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbltextPass.Location = new System.Drawing.Point(27, 16);
            this.lbltextPass.Name = "lbltextPass";
            this.lbltextPass.Size = new System.Drawing.Size(190, 19);
            this.lbltextPass.TabIndex = 10;
            this.lbltextPass.Text = "Your Recoverd Password is";
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.homeToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.homeToolStripMenuItem.Image = global::CheckMateApp.Properties.Resources.Home_icon;
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(77, 23);
            this.homeToolStripMenuItem.Text = "Home";
            this.homeToolStripMenuItem.Click += new System.EventHandler(this.homeToolStripMenuItem_Click);
            // 
            // FogotPassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CheckMateApp.Properties.Resources.main_back;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(723, 448);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pbpSearch);
            this.Controls.Add(this.txtpoDetail);
            this.Controls.Add(this.lblpoDetails);
            this.Controls.Add(this.cmbprOption);
            this.Controls.Add(this.lblprOption);
            this.Controls.Add(this.cmbpuType);
            this.Controls.Add(this.lblpuType);
            this.Controls.Add(this.PbforgotPass);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MaximizeBox = false;
            this.Name = "FogotPassword";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Password Find";
            ((System.ComponentModel.ISupportInitialize)(this.PbforgotPass)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbpSearch)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox PbforgotPass;
        private System.Windows.Forms.Label lblpuType;
        private System.Windows.Forms.ComboBox cmbpuType;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Label lblprOption;
        private System.Windows.Forms.ComboBox cmbprOption;
        private System.Windows.Forms.Label lblpoDetails;
        private System.Windows.Forms.TextBox txtpoDetail;
        private System.Windows.Forms.PictureBox pbpSearch;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblsowpass;
        private System.Windows.Forms.Label lbltextPass;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;


    }
}