﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CheckMateApp
{
    public partial class WordForm : Form
    {
        public WordForm()
        {
            InitializeComponent();
        }

        private void letterQuizToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LetterForm letter = new LetterForm();
            this.Hide();
            letter.Show();
        }

        private void sentenceQuizToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SentenceForm sentence = new SentenceForm();
            this.Hide();
            sentence.Show();
        }

        private void selfQuizToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SelfForm self = new SelfForm();
            this.Hide();
            self.Show();
        }

        private void checkResultToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResultForm result = new ResultForm();
            this.Hide();
            result.Show();
        }

        private void checkReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReportsForm report = new ReportsForm();
            this.Hide();
            report.Show();
        }

        private void settingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormMainPage mainform = new FormMainPage();
            this.Hide();
            mainform.Show();

        }

        

       
    }
}
