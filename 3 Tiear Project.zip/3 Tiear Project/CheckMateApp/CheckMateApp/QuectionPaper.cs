﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessAccessLayer;
using UserObjectLayer;
using System.Data;
using System.Data.SqlClient;

namespace CheckMateApp
{

    class QuectionPaper
    {
        public Informations info;
        public CoordinateManager con;
        private int quectionCount = 5;
        private int[] quectionList;
        private int diffultyLevel;
        private int UserAttemptCount;
        private List<KeyValuePair<int, Boolean>> quectionResultMap;

        public QuectionPaper(Informations i, CoordinateManager c)
        {
            info = i;
            con = c;
        }

        public void submit(int UserID, int[] results, int[] quections)
        {   
            // Format:
            //  submit(1, new int[5] { 1, 1, 1, 0, 0 }, new int[5] { 1, 2, 3, 4, 5 });

            string resultString = null;
            int marks = 0;
            for (int i = 0; i < results.Length ;i++ )
            {
                marks = results[i] + marks;
            }
            int attempt = getUserAttemptCount(UserID)+1;
            for (int j = 0; j < results.Length; j++ )
            {
                String partialResultString = "(" + UserID + "," + marks + "," + attempt + ", " + quections[j] + "," + results[j] + ")";
                if (j < results.Length-1)
                    partialResultString = "," + partialResultString;
                resultString = partialResultString + resultString;
            }
            info.resultString = resultString; 
            con.setUserMarks(info);

            info.attempt = attempt;
            info.userID = UserID;
            if (attempt == 1)
                con.insertUserAttemptCount(info);
            else
                con.updateUserAttemptCount(info);
        }
        public int[] getNextPaper(int userID)
        {
            int userAttempt = getUserAttemptCount(userID);
            quectionList = new int[quectionCount];
            info.userID = userID;

            submit(userID, new int[5] { 0, 1, 1, 0, 0 }, new int[5] { 6, 7, 8, 9, 10 });

            if (userAttempt>0)
            {
                DataSet nextPaperDataSet = new DataSet();
                nextPaperDataSet = con.getNextPaper(info);
                if (nextPaperDataSet.Tables[0].Rows.Count > 0)
                {
                    for (int k = 0; k < quectionCount; k++)
                    {
                        quectionList[k] = Convert.ToInt32(nextPaperDataSet.Tables[0].Rows[k][0]);

                    }
                }
            }
            else
            {
                DataSet nextQuectionDataSet = new DataSet();
                nextQuectionDataSet = con.getAllLetters();
                if (nextQuectionDataSet.Tables[0].Rows.Count > 0)
                {
                    int j = 0;
                    foreach (int i in GetRandomNumbers())
                    {
                        quectionList[j] = Convert.ToInt32(nextQuectionDataSet.Tables[0].Rows[i][0]);
                        j++;
                        if (j == quectionCount)
                            break;
                    }
                }
            }

            return quectionList;
        }

         public int getUserAttemptCount(int userID)
        {
            int userAttempt = 0;
            DataSet UserAttemptCountDataset = new DataSet();
            info.userID = userID;
            UserAttemptCountDataset = con.getUserAttemptCount(info);
            if (UserAttemptCountDataset.Tables[0].Rows.Count > 0)
            {
                userAttempt = Convert.ToInt32(UserAttemptCountDataset.Tables[0].Rows[0][0]);
            }
            return userAttempt;            
        }

        public void setUserAttemptCount (int userID, int attempCount)
        {
            // implement this inorder to update the attempt count of a user when user ID is provided
        }

        public void getUserAttemptResults(int userID, int attempt) 
        {

        }
        public void setUserAttemptResults(int userID, int attempt)
        {

        }

        public IEnumerable<int> GetRandomNumbers()
        {
            List<int> randomNumbers = new List<int>() {0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            Random rnd = new Random();
            return from i in randomNumbers orderby rnd.Next(randomNumbers.Count) select i;
        }
    }
}
