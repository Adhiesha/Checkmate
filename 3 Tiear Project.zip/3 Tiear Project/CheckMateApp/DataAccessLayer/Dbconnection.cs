﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer
{
    public class Dbconnection
    {
        public SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=CheckMateDB;Integrated Security=True");
        public SqlConnection getcon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            return con;
        }
        public int ExeNonQuery(SqlCommand cmd)
        {
            cmd.Connection = getcon();
            int rowsaffected = -1;
            rowsaffected = cmd.ExecuteNonQuery();
            con.Close();
            return rowsaffected;

        }
        public object ExeScaler(SqlCommand cmd)
        {
            cmd.Connection = getcon();
            object obj = -1;
            obj = cmd.ExecuteScalar();
            con.Close();
            return obj;
        }
        public DataTable ExeReader(SqlCommand cmd)
        {
            cmd.Connection = getcon();
            SqlDataReader sdr;
            DataTable dt = new DataTable();
            sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();
            return dt;
        }
        public DataSet Exedataset(SqlCommand cmd, String tableName)
        {
            cmd.Connection = getcon();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, tableName);
            con.Close();
            return ds;
        }

        public string ExeLetterFinder(SqlCommand cmd)
        {
            cmd.Connection = getcon();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("GetMatchLetter");
            da.Fill(dt);
            cmd.Dispose();
            if (dt.Rows.Count > 0)
            {
                return dt.Rows[0].Field<string>("LETTER");
            }
            else
            {
                return "Leter not found";
            } 
        }

        public DataSet ExecuteStoredPosedure(SqlCommand cmd)
        {
            cmd.Connection = getcon();
            SqlDataAdapter da = new SqlDataAdapter();
            DataSet ds = new DataSet();
            da.SelectCommand = cmd;
            da.Fill(ds);
            con.Close();
            return ds;
        }

        public int ExecuteQuery(SqlCommand cmd)
        {
            cmd.Connection = getcon();            
            return cmd.ExecuteNonQuery();
        }

    }
}
